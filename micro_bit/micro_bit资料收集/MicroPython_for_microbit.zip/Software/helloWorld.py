# SparkFun Electronics
# Experiment 0.0
# Display "Hello World!" on your micro:bit

from microbit import *

while True:
    display.scroll("Hello World!")
    sleep(1000)
