# SparkFun Electronics
# Experiment 0.1
# Display an image

from microbit import *

while True:
    display.show(Image.DUCK)
