# SparkFun Electronics
# Experiment 0.2
# Display a custom image

from microbit import *

while True:
    star = Image("00900:99599:05950:09590:90009")
    display.show(star)
